<?php
require "config.php";
$arr = array("arif", 12, 48, "asif");
pr($arr);
$arr2 = array_pop($arr);
pr($arr);
pr($arr2);

?>