<?php
$x = true;
echo gettype($x)."<br>";
if($x){
	echo "This is if statement";
}else{
	echo "this is not";
}



?>