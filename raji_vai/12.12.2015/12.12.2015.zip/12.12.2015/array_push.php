<?php
require "config.php";
$arr = array("apple","mango");
pr($arr);
$arr2 = array(12,11);
array_push($arr,$arr2);
pr($arr);

?>