<?php
$arr = array("Dhaka", "Rangpur", "Dinajpur", "Khulna");
$implode_var = implode(", ", $arr);
echo $implode_var;
?>