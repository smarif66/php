<?php
$fruits = "fruit1 fruit2 fruit3 fruit4 fruit5 fruit6";
$fruits_explod = explode(" ", $fruits);
echo $fruits_explod[0];
echo $fruits_explod[1];




?>